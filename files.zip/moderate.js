export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  const { text } = req.body;
  if (!text) return res.status(400).json({ error: 'No text provided' });

  try {
    const response = await fetch('https://api.openai.com/v1/moderations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify({ input: text })
    });

    const data = await response.json();
    const result = data.results[0];

    if (result.flagged) {
      // Find which category triggered it
      const categories = result.categories;
      let reason = 'Content policy violation';
      if (categories.hate || categories['hate/threatening']) reason = 'Hate speech or threatening language';
      else if (categories.harassment) reason = 'Harassment or abusive language';
      else if (categories['sexual/minors'] || categories.sexual) reason = 'Sexually explicit content';
      else if (categories.violence || categories['violence/graphic']) reason = 'Violent content';
      else if (categories['self-harm']) reason = 'Self-harm related content';

      return res.status(200).json({ safe: false, reason });
    }

    return res.status(200).json({ safe: true });

  } catch (err) {
    // If moderation API fails, fall through — don't block legitimate users
    console.error('Moderation error:', err);
    return res.status(200).json({ safe: true });
  }
}
